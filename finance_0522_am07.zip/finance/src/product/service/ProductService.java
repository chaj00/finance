package product.service;

public interface ProductService {

}
