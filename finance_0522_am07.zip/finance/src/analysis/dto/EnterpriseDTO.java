package analysis.dto;

public class EnterpriseDTO {

	private int iCheckNumber1;	//
	private int iCheckNumber2;
	private int iCheckNumber3;
	private int iCheckNumber4;
	private int iCheckNumber5;
	private int iCheckNumber_total;
	private int iCheckNumber_avg;
	
	
	
	
	
}
