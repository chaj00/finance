package analysis.service;

public interface ProductService {

}
