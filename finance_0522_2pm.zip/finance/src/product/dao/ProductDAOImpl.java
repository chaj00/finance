package product.dao;

public class ProductDAOImpl implements ProductDAO{

}
