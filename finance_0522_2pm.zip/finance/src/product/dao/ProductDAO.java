package product.dao;

public interface ProductDAO {

}
