package analysis.dao;

public class AnalysisDAOImpl implements AnalysisDAO{

}
