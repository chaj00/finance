package analysis.dao;

public interface AnalysisDAO {

}
