select * from tab;
select * from PRODUCTS;


select ROUND(avg(SIXPROFIT),2) from PRODUCTS where classify = '�ؿ�' and std >= 25;

select SIXPROFIT from PRODUCTS where classify = '����' and std >= 25;
select SIXPROFIT from PRODUCTS where classify = '����' and std > 15 and std < 25;
select SIXPROFIT from PRODUCTS where classify = '����' and std > 10 and std < 15;
select * from PRODUCTS where classify = '����' and std > 5 and std < 10;
select * from PRODUCTS where classify = '����' and std > 0 and std < 5;
select * from PRODUCTS where classify = '�ؿ�' and std >= 25;
select * from PRODUCTS where classify = '�ؿ�' and std > 15 and std < 25;
select * from PRODUCTS where classify = '�ؿ�' and std > 10 and std < 15;
select * from PRODUCTS where classify = '�ؿ�' and std > 5 and std < 10;
select * from PRODUCTS where classify = '�ؿ�' and std > 0 and std < 5;