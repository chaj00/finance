package portfolio.controller;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet(name = "portfolio", urlPatterns = { "/portfolio.do" })
public class PortfolioServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		String initInvestPrice = req.getParameter("initInvestPrice");
		String NowAge = req.getParameter("NowAge");
		String MonthSavePrice = req.getParameter("MonthSavePrice");
		String ForecastRetire = req.getParameter("ForecastRetire");
		
		System.out.println(initInvestPrice + NowAge + MonthSavePrice + ForecastRetire);
		
		
	    RequestDispatcher rd = req.getRequestDispatcher("/portfolio/portfolio_result.jsp");
	    rd.forward(req, res);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");
		String initInvestPrice = req.getParameter("txt_initInvestPrice");
		String NowAge = req.getParameter("txt_NowAge");
		String MonthSavePrice = req.getParameter("txt_MonthSavePrice");
		String ForecastRetire = req.getParameter("txt_ForecastRetire");
		System.out.println(initInvestPrice + NowAge + MonthSavePrice + ForecastRetire);
		
		
		 RequestDispatcher rd = req.getRequestDispatcher("/portfolio/portfolio_result.jsp");
		 rd.forward(req, res);
}
}
