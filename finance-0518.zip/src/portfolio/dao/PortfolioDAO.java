package portfolio.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import portfolio.dto.PortfolioDTO;

public interface PortfolioDAO {

	ArrayList<PortfolioDTO> search(String prdname, Connection con) 
			throws SQLException;
	
}
