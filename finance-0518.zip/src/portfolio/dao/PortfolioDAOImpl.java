package portfolio.dao;

import static fw.Query.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import portfolio.dto.PortfolioDTO;

public class PortfolioDAOImpl implements PortfolioDAO{

	@Override
	public ArrayList<PortfolioDTO> search(String prdname, Connection con) throws SQLException {

		ArrayList<PortfolioDTO> prdlist = new ArrayList<PortfolioDTO>();
		PortfolioDTO dto = null;
		System.out.println("��ǰ��" + prdname);
		PreparedStatement ptmt = con.prepareStatement(K_RISKP_5);
		
		return null;
	}

}
