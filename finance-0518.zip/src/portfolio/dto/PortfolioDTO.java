package portfolio.dto;

public class PortfolioDTO {

	private String title;
	private String classify;
	private String type;
	private String threeprofit;
	private String std;
	
	
	
	
	public PortfolioDTO(String title, String classify, String type, String threeprofit, String std) {
		super();
		this.title = title;
		this.classify = classify;
		this.type = type;
		this.threeprofit = threeprofit;
		this.std = std;
	}




	public String getTitle() {
		return title;
	}




	public void setTitle(String title) {
		this.title = title;
	}




	public String getClassify() {
		return classify;
	}




	public void setClassify(String classify) {
		this.classify = classify;
	}




	public String getType() {
		return type;
	}




	public void setType(String type) {
		this.type = type;
	}




	public String getThreeprofit() {
		return threeprofit;
	}




	public void setThreeprofit(String threeprofit) {
		this.threeprofit = threeprofit;
	}




	public String getStd() {
		return std;
	}




	public void setStd(String std) {
		this.std = std;
	}




	@Override
	public String toString() {
		return "PortfolioDTO [title=" + title + ", classify=" + classify + ", type=" + type + ", threeprofit="
				+ threeprofit + ", std=" + std + "]";
	}
	
	
	
	
}
