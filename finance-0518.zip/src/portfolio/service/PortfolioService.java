package portfolio.service;

import java.util.ArrayList;

import portfolio.dto.PortfolioDTO;


public interface PortfolioService {
	
	ArrayList<PortfolioDTO> search(String prdname);
	



}
