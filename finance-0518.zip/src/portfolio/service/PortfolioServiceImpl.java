package portfolio.service;

import static fw.JdbcTemplate.*;
import java.sql.Connection;
import java.util.ArrayList;

import portfolio.dao.PortfolioDAO;
import portfolio.dao.PortfolioDAOImpl;
import portfolio.dto.PortfolioDTO;

public class PortfolioServiceImpl implements PortfolioService{

	@Override
	public ArrayList<PortfolioDTO> search(String prdname) {
	
		ArrayList<PortfolioDTO> prdlist = new ArrayList<PortfolioDTO>();
		System.out.println("��ǰ�� : "+ prdname);
		Connection con = getConnect();
		PortfolioDAO dao = new PortfolioDAOImpl();
		
		
		
		return prdlist;
		
	}

}
